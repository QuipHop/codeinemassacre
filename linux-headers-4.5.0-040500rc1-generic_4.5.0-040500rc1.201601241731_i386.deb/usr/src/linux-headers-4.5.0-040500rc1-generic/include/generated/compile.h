/* This file is auto generated, version 201601241731 */
/* SMP */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#201601241731 SMP Sun Jan 24 22:47:08 UTC 2016"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "tangerine"
#define LINUX_COMPILER "gcc version 5.2.1 20151010 (Ubuntu 5.2.1-22ubuntu2) "
